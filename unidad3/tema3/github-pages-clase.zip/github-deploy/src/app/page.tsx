"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Server,
  Cpu,
  HardDrive,
  Wifi,
  Shield,
  Cloud,
  Monitor,
  Network,
  CheckCircle2,
  XCircle,
  ChevronRight,
  BookOpen,
  Target,
  Lightbulb,
  ClipboardList,
  ArrowRight,
  Clock,
  Users,
  GraduationCap,
  Zap,
  Database,
  Globe,
  Lock,
  BarChart3,
  Play,
  RotateCcw,
  Trophy,
  AlertTriangle,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

/* ───────────── animation helpers ───────────── */
const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.08, duration: 0.5, ease: "easeOut" },
  }),
};

const stagger = {
  visible: { transition: { staggerChildren: 0.08 } },
};

/* ───────────── data ───────────── */
const objectives = [
  { icon: Target, text: "Comprender qué son los requerimientos tecnológicos y por qué son esenciales en todo proyecto." },
  { icon: Cpu, text: "Identificar los componentes clave de infraestructura tecnológica: hardware, software, red y seguridad." },
  { icon: ClipboardList, text: "Aplicar una metodología básica para levantar y documentar requerimientos de TI." },
  { icon: BarChart3, text: "Evaluar costos, riesgos y alternativas al definir la infraestructura de un proyecto." },
];

const conceptCards = [
  {
    icon: Server,
    title: "Hardware",
    color: "from-emerald-500 to-teal-600",
    bgColor: "bg-emerald-50 dark:bg-emerald-950/40",
    borderColor: "border-emerald-200 dark:border-emerald-800",
    description:
      "Equipos físicos necesarios: servidores, computadoras de escritorio, laptops, dispositivos de red, almacenamiento externo y periféricos. Incluye la capacidad de procesamiento, memoria RAM y espacio en disco requerido para cada estación de trabajo o servidor del proyecto.",
    examples: [
      "Servidores con 64 GB RAM y procesadores Xeon para bases de datos",
      "Estaciones de trabajo con 16 GB RAM para diseño gráfico",
      "Almacenamiento NAS de 8 TB para respaldo de archivos",
      "Impresoras multifunción para documentación del proyecto",
    ],
  },
  {
    icon: Monitor,
    title: "Software",
    color: "from-violet-500 to-purple-600",
    bgColor: "bg-violet-50 dark:bg-violet-950/40",
    borderColor: "border-violet-200 dark:border-violet-800",
    description:
      "Aplicaciones, sistemas operativos, licencias y herramientas de desarrollo necesarias. Abarca desde el sistema operativo base hasta software especializado de gestión, pasando por suites ofimáticas y herramientas de colaboración en equipo.",
    examples: [
      "Sistema operativo Windows 11 Pro o Ubuntu Server",
      "Suite ofimática Microsoft 365 o Google Workspace",
      "Herramientas de gestión: Jira, Trello, Asana o MS Project",
      "IDEs: Visual Studio Code, IntelliJ para el equipo de desarrollo",
    ],
  },
  {
    icon: Wifi,
    title: "Red y Conectividad",
    color: "from-amber-500 to-orange-600",
    bgColor: "bg-amber-50 dark:bg-amber-950/40",
    borderColor: "border-amber-200 dark:border-amber-800",
    description:
      "Infraestructura de comunicación: conexiones a internet, redes LAN/WLAN, switches, routers, firewalls de red y ancho de banda. Es fundamental garantizar la comunicación fluida entre equipos, clientes y proveedores del proyecto.",
    examples: [
      "Conexión de fibra óptica de 200 Mbps simétricos",
      "Red Wi-Fi 6 (802.11ax) para áreas de trabajo compartidas",
      "VPN site-to-site para conectar oficinas remotas",
      "Switches gestionables de 24 puertos Gigabit Ethernet",
    ],
  },
  {
    icon: Shield,
    title: "Seguridad",
    color: "from-rose-500 to-red-600",
    bgColor: "bg-rose-50 dark:bg-rose-950/40",
    borderColor: "border-rose-200 dark:border-rose-800",
    description:
      "Protección de datos, sistemas y usuarios: antivirus, firewalls, copias de seguridad, políticas de acceso, autenticación multifactor y cumplimiento normativo. La seguridad no es opcional: debe integrarse desde el inicio del proyecto.",
    examples: [
      "Antivirus empresarial con protección en tiempo real",
      "Firewall de próxima generación (NGFW) con IDS/IPS",
      "Política de copias de seguridad diarias con retención de 30 días",
      "Autenticación multifactor (MFA) para todos los accesos",
    ],
  },
  {
    icon: Cloud,
    title: "Servicios en la Nube",
    color: "from-sky-500 to-cyan-600",
    bgColor: "bg-sky-50 dark:bg-sky-950/40",
    borderColor: "border-sky-200 dark:border-sky-800",
    description:
      "Plataformas cloud como AWS, Azure o Google Cloud que ofrecen escalabilidad, almacenamiento remoto, bases de datos gestionadas y servicios de computación bajo demanda. Permiten reducir costos de infraestructura física y escalar según demanda.",
    examples: [
      "AWS EC2 para servidores virtuales escalables",
      "Azure Blob Storage para almacenamiento de archivos",
      "Google Cloud SQL para bases de datos relacionales gestionadas",
      "Cloudflare CDN para aceleración de contenido web",
    ],
  },
  {
    icon: Database,
    title: "Almacenamiento de Datos",
    color: "from-pink-500 to-fuchsia-600",
    bgColor: "bg-pink-50 dark:bg-pink-950/40",
    borderColor: "border-pink-200 dark:border-pink-800",
    description:
      "Sistemas de gestión de bases de datos (relacionales y NoSQL), almacenamiento en bloque, archivos distribuidos y estrategias de respaldo. Los datos son el activo más valioso de cualquier proyecto tecnológico.",
    examples: [
      "PostgreSQL o MySQL para bases de datos transaccionales",
      "MongoDB para datos no estructurados y documentos",
      "Redis para caché en memoria de alta velocidad",
      "Sistema de respaldo con estrategia 3-2-1 (3 copias, 2 medios, 1 externa)",
    ],
  },
];

const methodologySteps = [
  {
    step: 1,
    title: "Identificar Necesidades del Negocio",
    description:
      "El primer paso consiste en comprender profundamente qué necesita el proyecto para funcionar correctamente. Esto implica entrevistas con stakeholders, análisis del alcance del proyecto y definición clara de los objetivos de negocio que la tecnología debe soportar.",
    tips: [
      "Realiza entrevistas estructuradas con cada jefe de área",
      "Documenta los procesos actuales que serán automatizados",
      "Define métricas de éxito para cada requerimiento",
      "Identifica restricciones presupuestarias y de tiempo",
    ],
    icon: Lightbulb,
  },
  {
    step: 2,
    title: "Inventario de Recursos Existentes",
    description:
      "Antes de adquirir nueva tecnología, es fundamental conocer qué recursos ya dispone la organización. Un inventario completo permite evitar duplicaciones, identificar brechas y optimizar la inversión. Incluye hardware, software, licencias vigentes y capacidades de red actuales.",
    tips: [
      "Usa herramientas como Lansweeper o Snipe-IT para el inventario",
      "Verifica fechas de vencimiento de licencias",
      "Evalúa si los equipos actuales cumplen los requisitos mínimos",
      "Documenta la edad y estado de cada activo tecnológico",
    ],
    icon: ClipboardList,
  },
  {
    step: 3,
    title: "Definir Requerimientos Técnicos",
    description:
      "Con base en las necesidades y el inventario, se detallan las especificaciones técnicas precisas: capacidad de procesamiento, almacenamiento, ancho de banda, software requerido, niveles de servicio (SLAs) y estándares de compatibilidad que debe cumplir cada componente tecnológico.",
    tips: [
      "Especifica requerimientos mínimos y recomendados",
      "Incluye requisitos de interoperabilidad entre sistemas",
      "Define SLAs con porcentajes de disponibilidad (ej: 99.9%)",
      "Considera requisitos de escalabilidad a 3-5 años",
    ],
    icon: Cpu,
  },
  {
    step: 4,
    title: "Evaluar Alternativas y Costos",
    description:
      "Investigar y comparar diferentes soluciones tecnológicas del mercado. Cada alternativa debe evaluarse en función de costo total de propiedad (TCO), soporte del proveedor, compatibilidad, y opiniones de otros usuarios. No siempre la opción más barata es la mejor a largo plazo.",
    tips: [
      "Calcula el TCO (Total Cost of Ownership) a 3 y 5 años",
      "Solicita al menos 3 cotizaciones a proveedores diferentes",
      "Evalúa costos ocultos: capacitación, migración, mantenimiento",
      "Considera opciones open source vs. software propietario",
    ],
    icon: BarChart3,
  },
  {
    step: 5,
    title: "Plan de Implementación y Pruebas",
    description:
      "Diseñar la hoja de ruta para desplegar la infraestructura: cronograma detallado, responsables, puntos de verificación, plan de contingencia y criterios de aceptación. Las pruebas piloto son esenciales antes del despliegue completo para mitigar riesgos.",
    tips: [
      "Usa un entorno de pruebas (staging) antes de producción",
      "Define un plan de rollback en caso de falla",
      "Establece métricas de validación para cada componente",
      "Programa capacitación del equipo antes del lanzamiento",
    ],
    icon: Zap,
  },
  {
    step: 6,
    title: "Documentación y Mantenimiento",
    description:
      "Todo requerimiento debe quedar documentado formalmente en un documento de Especificación de Requerimientos Tecnológicos (ERT). Además, se define el plan de mantenimiento preventivo y correctivo, actualizaciones periódicas y monitoreo continuo del desempeño de la infraestructura.",
    tips: [
      "Crea un documento ERT firmado por todos los stakeholders",
      "Establece un calendario de mantenimiento preventivo",
      "Implementa monitoreo con herramientas como Nagios o Zabbix",
      "Define un proceso de gestión de cambios para la infraestructura",
    ],
    icon: BookOpen,
  },
];

const quizQuestions = [
  {
    question: "¿Cuál de los siguientes NO es un componente de infraestructura tecnológica?",
    options: ["Hardware y servidores", "Políticas de recursos humanos", "Red y conectividad", "Software y licencias"],
    correct: 1,
    explanation:
      "Las políticas de recursos humanos pertenecen al área de gestión humana, no a la infraestructura tecnológica. Los componentes tecnológicos son: hardware, software, red, seguridad y servicios en la nube.",
  },
  {
    question: "¿Qué es el TCO (Total Cost of Ownership)?",
    options: [
      "El costo de compra inicial del equipo",
      "El costo total de propiedad incluyendo adquisición, operación y mantenimiento a lo largo del tiempo",
      "El presupuesto mensual del departamento de TI",
      "El costo de licenciamiento de software únicamente",
    ],
    correct: 1,
    explanation:
      "El TCO incluye no solo el costo de adquisición, sino también los costos de operación, mantenimiento, capacitación, actualizaciones y eventual reemplazo durante toda la vida útil del activo tecnológico.",
  },
  {
    question: "¿Por qué es importante realizar un inventario de recursos existentes antes de definir nuevos requerimientos?",
    options: [
      "Solo por cumplimiento contable",
      "Para evitar duplicaciones, optimizar la inversión y detectar brechas",
      "No es necesario, siempre se debe comprar todo nuevo",
      "Solo para saber qué se puede vender",
    ],
    correct: 1,
    explanation:
      "El inventario permite conocer qué recursos ya se tienen, evitar comprar algo que ya existe, identificar qué equipos necesitan actualización y optimizar cada peso invertido en tecnología.",
  },
  {
    question: "¿Qué significa un SLA de 99.9% de disponibilidad?",
    options: [
      "El sistema funciona perfecto todo el tiempo",
      "El sistema puede estar caído hasta 8.76 horas al año (aprox. 43 minutos al mes)",
      "El sistema falla el 0.1% de las transacciones",
      "El sistema se actualiza cada 99.9 días",
    ],
    correct: 1,
    explanation:
      "99.9% de disponibilidad (conocido como 'tres nueves') permite hasta 8.76 horas de downtime al año. Es un estándar común para sistemas críticos de negocio. Cinco nueves (99.999%) permite solo 5.26 minutos al año.",
  },
  {
    question: "¿Cuál es la estrategia de respaldo 3-2-1?",
    options: [
      "3 copias en el mismo disco, 2 veces al día, 1 administrador",
      "3 copias de los datos, en 2 medios diferentes, con 1 copia fuera de las instalaciones",
      "3 proveedores de respaldo, 2 servidores, 1 contrato",
      "3 días de retención, 2 usuarios con acceso, 1 contraseña maestra",
    ],
    correct: 1,
    explanation:
      "La regla 3-2-1 es un estándar de la industria: mantener al menos 3 copias de los datos, almacenadas en al menos 2 tipos de medios diferentes, con al menos 1 copia almacenada externamente (offsite) o en la nube.",
  },
];

/* ───────────── components ───────────── */

function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      {/* Animated background shapes */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          className="absolute -top-40 -right-40 h-80 w-80 rounded-full bg-emerald-500/10 blur-3xl"
          animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.5, 0.3] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute -bottom-40 -left-40 h-80 w-80 rounded-full bg-violet-500/10 blur-3xl"
          animate={{ scale: [1.2, 1, 1.2], opacity: [0.5, 0.3, 0.5] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-96 w-96 rounded-full bg-amber-500/5 blur-3xl"
          animate={{ scale: [1, 1.3, 1], opacity: [0.2, 0.4, 0.2] }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
        />
        {/* Grid pattern overlay */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
            backgroundSize: "50px 50px",
          }}
        />
      </div>

      <div className="relative mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
        <motion.div initial="hidden" animate="visible" variants={stagger} className="text-center">
          <motion.div variants={fadeUp} custom={0}>
            <Badge className="mb-6 border-emerald-500/30 bg-emerald-500/10 px-4 py-1.5 text-sm font-medium text-emerald-300 backdrop-blur-sm">
              <GraduationCap className="mr-2 h-4 w-4" />
              Gestión de Proyectos — Nivel Básico
            </Badge>
          </motion.div>

          <motion.h1
            variants={fadeUp}
            custom={1}
            className="text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl xl:text-6xl"
          >
            Determinación de{" "}
            <span className="bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400 bg-clip-text text-transparent">
              Requerimientos Tecnológicos
            </span>{" "}
            e Infraestructura
          </motion.h1>

          <motion.p
            variants={fadeUp}
            custom={2}
            className="mx-auto mt-6 max-w-2xl text-base text-slate-300 sm:text-lg"
          >
            Aprende a identificar, evaluar y documentar los recursos tecnológicos
            necesarios para ejecutar un proyecto de manera exitosa. Desde el
            hardware hasta la nube, cada decisión cuenta.
          </motion.p>

          <motion.div variants={fadeUp} custom={3} className="mt-8 flex flex-wrap items-center justify-center gap-4">
            <div className="flex items-center gap-2 rounded-full bg-white/5 px-4 py-2 text-sm backdrop-blur-sm">
              <Clock className="h-4 w-4 text-amber-400" />
              <span>Clase de 1 hora</span>
            </div>
            <div className="flex items-center gap-2 rounded-full bg-white/5 px-4 py-2 text-sm backdrop-blur-sm">
              <Users className="h-4 w-4 text-violet-400" />
              <span>Nivel Básico</span>
            </div>
            <div className="flex items-center gap-2 rounded-full bg-white/5 px-4 py-2 text-sm backdrop-blur-sm">
              <BookOpen className="h-4 w-4 text-cyan-400" />
              <span>5 temas clave</span>
            </div>
          </motion.div>

          <motion.div variants={fadeUp} custom={4} className="mt-10">
            <Button
              size="lg"
              className="group gap-2 bg-gradient-to-r from-emerald-500 to-teal-600 px-8 text-white shadow-lg shadow-emerald-500/25 hover:from-emerald-600 hover:to-teal-700"
              onClick={() => {
                document.getElementById("objetivos")?.scrollIntoView({ behavior: "smooth" });
              }}
            >
              Comenzar la clase
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Button>
          </motion.div>
        </motion.div>

        {/* Floating icons */}
        <motion.div
          className="absolute left-8 top-1/4 hidden text-emerald-500/20 lg:block"
          animate={{ y: [-10, 10, -10] }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
        >
          <Server className="h-16 w-16" />
        </motion.div>
        <motion.div
          className="absolute right-8 top-1/3 hidden text-violet-500/20 lg:block"
          animate={{ y: [10, -10, 10] }}
          transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
        >
          <Cloud className="h-14 w-14" />
        </motion.div>
        <motion.div
          className="absolute bottom-16 left-16 hidden text-amber-500/20 lg:block"
          animate={{ y: [-8, 12, -8] }}
          transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
        >
          <Shield className="h-12 w-12" />
        </motion.div>
        <motion.div
          className="absolute right-20 bottom-20 hidden text-cyan-500/20 lg:block"
          animate={{ y: [12, -8, 12] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        >
          <Globe className="h-14 w-14" />
        </motion.div>
      </div>
    </section>
  );
}

function ObjectivesSection() {
  return (
    <section id="objetivos" className="bg-white py-16 sm:py-20 lg:py-24">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={stagger}
        >
          <motion.div variants={fadeUp} custom={0} className="text-center">
            <Badge variant="secondary" className="mb-3">
              <Target className="mr-1.5 h-3.5 w-3.5" />
              Objetivos de Aprendizaje
            </Badge>
            <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">
              ¿Qué aprenderás en esta clase?
            </h2>
            <p className="mx-auto mt-3 max-w-2xl text-muted-foreground">
              Al finalizar esta sesión de 1 hora, serás capaz de comprender y aplicar los conceptos
              fundamentales para definir la infraestructura tecnológica de cualquier proyecto.
            </p>
          </motion.div>

          <div className="mt-12 grid gap-6 sm:grid-cols-2">
            {objectives.map((obj, i) => (
              <motion.div key={i} variants={fadeUp} custom={i + 1}>
                <Card className="group h-full border-border/50 transition-all duration-300 hover:border-emerald-200 hover:shadow-lg hover:shadow-emerald-500/5 dark:hover:border-emerald-800">
                  <CardContent className="flex items-start gap-4 p-6">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-md shadow-emerald-500/20">
                      <obj.icon className="h-6 w-6" />
                    </div>
                    <div>
                      <h3 className="font-semibold leading-tight">
                        Objetivo {i + 1}
                      </h3>
                      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                        {obj.text}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function ConceptCard({
  concept,
  index,
}: {
  concept: (typeof conceptCards)[0];
  index: number;
}) {
  return (
    <motion.div
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-50px" }}
      variants={fadeUp}
      custom={index}
    >
      <Card className={`group h-full border-border/50 transition-all duration-300 hover:shadow-xl ${concept.borderColor} dark:border-opacity-30`}>
        <CardHeader className="pb-3">
          <div className="flex items-center gap-3">
            <div
              className={`flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${concept.color} text-white shadow-lg`}
            >
              <concept.icon className="h-6 w-6" />
            </div>
            <div>
              <CardTitle className="text-lg">{concept.title}</CardTitle>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm leading-relaxed text-muted-foreground">
            {concept.description}
          </p>
          <Separator />
          <div>
            <h4 className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              <Lightbulb className="h-3.5 w-3.5" />
              Ejemplos prácticos
            </h4>
            <ul className="space-y-1.5">
              {concept.examples.map((ex, j) => (
                <li
                  key={j}
                  className="flex items-start gap-2 text-sm text-muted-foreground"
                >
                  <ChevronRight className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-500" />
                  <span>{ex}</span>
                </li>
              ))}
            </ul>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function ConceptsSection() {
  const [activeTab, setActiveTab] = useState("grid");

  return (
    <section className="bg-slate-50 py-16 sm:py-20 lg:py-24 dark:bg-slate-900/50">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={stagger}
        >
          <motion.div variants={fadeUp} custom={0} className="text-center">
            <Badge variant="secondary" className="mb-3">
              <Cpu className="mr-1.5 h-3.5 w-3.5" />
              Componentes Clave
            </Badge>
            <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">
              Infraestructura Tecnológica
            </h2>
            <p className="mx-auto mt-3 max-w-2xl text-muted-foreground">
              Los seis pilares fundamentales que conforman la infraestructura tecnológica de un
              proyecto. Conoce cada uno en detalle con ejemplos reales.
            </p>
          </motion.div>

          <motion.div variants={fadeUp} custom={1} className="mt-8 flex justify-center">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full max-w-md">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="grid">
                  <div className="flex items-center gap-1.5">
                    <Network className="h-3.5 w-3.5" />
                    Vista General
                  </div>
                </TabsTrigger>
                <TabsTrigger value="detail">
                  <div className="flex items-center gap-1.5">
                    <BookOpen className="h-3.5 w-3.5" />
                    Detalle
                  </div>
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </motion.div>

          <AnimatePresence mode="wait">
            {activeTab === "grid" ? (
              <motion.div
                key="grid"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ duration: 0.3 }}
                className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3"
              >
                {conceptCards.map((concept, i) => (
                  <ConceptCard key={concept.title} concept={concept} index={i} />
                ))}
              </motion.div>
            ) : (
              <motion.div
                key="detail"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
                className="mt-10"
              >
                <Accordion type="single" collapsible className="space-y-3">
                  {conceptCards.map((concept, i) => (
                    <motion.div
                      key={concept.title}
                      initial="hidden"
                      whileInView="visible"
                      viewport={{ once: true }}
                      variants={fadeUp}
                      custom={i}
                    >
                      <Card className="border-border/50">
                        <AccordionItem value={`item-${i}`} className="border-0">
                          <AccordionTrigger className="px-6 py-4 hover:no-underline">
                            <div className="flex items-center gap-3">
                              <div
                                className={`flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br ${concept.color} text-white`}
                              >
                                <concept.icon className="h-5 w-5" />
                              </div>
                              <span className="text-left font-semibold">
                                {i + 1}. {concept.title}
                              </span>
                            </div>
                          </AccordionTrigger>
                          <AccordionContent className="px-6 pb-6">
                            <p className="mb-4 leading-relaxed text-muted-foreground">
                              {concept.description}
                            </p>
                            <div className="rounded-lg bg-muted/50 p-4">
                              <h4 className="mb-2 text-sm font-semibold">
                                Ejemplos prácticos:
                              </h4>
                              <ul className="space-y-2">
                                {concept.examples.map((ex, j) => (
                                  <li
                                    key={j}
                                    className="flex items-start gap-2 text-sm text-muted-foreground"
                                  >
                                    <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" />
                                    <span>{ex}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                      </Card>
                    </motion.div>
                  ))}
                </Accordion>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  );
}

function MethodologySection() {
  return (
    <section className="bg-white py-16 sm:py-20 lg:py-24">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={stagger}
        >
          <motion.div variants={fadeUp} custom={0} className="text-center">
            <Badge variant="secondary" className="mb-3">
              <ClipboardList className="mr-1.5 h-3.5 w-3.5" />
              Metodología
            </Badge>
            <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">
              Proceso de Determinación en 6 Pasos
            </h2>
            <p className="mx-auto mt-3 max-w-2xl text-muted-foreground">
              Una metodología estructurada paso a paso que te guiará desde la
              identificación de necesidades hasta la documentación final de los
              requerimientos tecnológicos de tu proyecto.
            </p>
          </motion.div>

          <div className="relative mt-14">
            {/* Vertical line */}
            <div className="absolute left-6 top-0 hidden h-full w-0.5 bg-gradient-to-b from-emerald-500 via-teal-500 to-cyan-500 sm:block" />

            <div className="space-y-8 sm:pl-16">
              {methodologySteps.map((step, i) => (
                <motion.div
                  key={step.step}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true, margin: "-50px" }}
                  variants={fadeUp}
                  custom={i}
                >
                  <Card className="group relative overflow-hidden border-border/50 transition-all duration-300 hover:border-emerald-200 hover:shadow-lg hover:shadow-emerald-500/5 dark:hover:border-emerald-800">
                    {/* Step number indicator - desktop */}
                    <div className="absolute -left-16 top-6 hidden h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 text-lg font-bold text-white shadow-lg shadow-emerald-500/25 sm:flex">
                      {step.step}
                    </div>
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        {/* Step number - mobile */}
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-sm font-bold text-white sm:hidden">
                          {step.step}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <step.icon className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
                            <h3 className="text-lg font-semibold">{step.title}</h3>
                          </div>
                          <p className="mt-2 leading-relaxed text-muted-foreground">
                            {step.description}
                          </p>
                          <div className="mt-4 rounded-lg bg-amber-50 p-4 dark:bg-amber-950/20">
                            <h4 className="mb-2 flex items-center gap-1.5 text-sm font-semibold text-amber-700 dark:text-amber-400">
                              <AlertTriangle className="h-3.5 w-3.5" />
                              Consejos prácticos
                            </h4>
                            <ul className="grid gap-2 sm:grid-cols-2">
                              {step.tips.map((tip, j) => (
                                <li
                                  key={j}
                                  className="flex items-start gap-2 text-sm text-muted-foreground"
                                >
                                  <ChevronRight className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-500" />
                                  <span>{tip}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function QuizSection() {
  const [currentQ, setCurrentQ] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);
  const [answers, setAnswers] = useState<(boolean | null)[]>(
    new Array(quizQuestions.length).fill(null)
  );

  const q = quizQuestions[currentQ];

  const handleSelect = (idx: number) => {
    if (showResult) return;
    setSelected(idx);
  };

  const handleCheck = () => {
    if (selected === null) return;
    const correct = selected === q.correct;
    setShowResult(true);
    const newAnswers = [...answers];
    newAnswers[currentQ] = correct;
    setAnswers(newAnswers);
    if (correct) setScore((s) => s + 1);
  };

  const handleNext = () => {
    if (currentQ < quizQuestions.length - 1) {
      setCurrentQ((c) => c + 1);
      setSelected(null);
      setShowResult(false);
    } else {
      setFinished(true);
    }
  };

  const handleReset = () => {
    setCurrentQ(0);
    setSelected(null);
    setShowResult(false);
    setScore(0);
    setFinished(false);
    setAnswers(new Array(quizQuestions.length).fill(null));
  };

  const percentage = Math.round((score / quizQuestions.length) * 100);

  return (
    <section className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 py-16 sm:py-20 lg:py-24 text-white">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={stagger}
        >
          <motion.div variants={fadeUp} custom={0} className="text-center">
            <Badge className="mb-3 border-violet-500/30 bg-violet-500/10 text-violet-300">
              <Play className="mr-1.5 h-3.5 w-3.5" />
              Evalúa tu Conocimiento
            </Badge>
            <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">
              Quiz Interactivo
            </h2>
            <p className="mx-auto mt-3 max-w-xl text-slate-400">
              Pon a prueba lo aprendido con 5 preguntas sobre requerimientos
              tecnológicos e infraestructura.
            </p>
          </motion.div>

          <motion.div variants={fadeUp} custom={1} className="mt-10">
            {!finished ? (
              <Card className="border-white/10 bg-white/5 backdrop-blur-xl">
                <CardContent className="p-6 sm:p-8">
                  {/* Progress */}
                  <div className="mb-6 flex items-center justify-between">
                    <span className="text-sm text-slate-400">
                      Pregunta {currentQ + 1} de {quizQuestions.length}
                    </span>
                    <span className="text-sm font-medium text-emerald-400">
                      Puntaje: {score}/{currentQ + (showResult ? 1 : 0)}
                    </span>
                  </div>
                  <Progress
                    value={((currentQ + (showResult ? 1 : 0)) / quizQuestions.length) * 100}
                    className="mb-8 h-2 bg-white/10"
                  />

                  {/* Question */}
                  <h3 className="mb-6 text-lg font-semibold leading-relaxed">
                    {q.question}
                  </h3>

                  {/* Options */}
                  <div className="space-y-3">
                    {q.options.map((opt, idx) => {
                      let borderClass = "border-white/10 hover:border-white/30";
                      let bgClass = "bg-white/5";
                      let icon = null;

                      if (showResult) {
                        if (idx === q.correct) {
                          borderClass = "border-emerald-500/50";
                          bgClass = "bg-emerald-500/10";
                          icon = <CheckCircle2 className="h-5 w-5 text-emerald-400" />;
                        } else if (idx === selected && idx !== q.correct) {
                          borderClass = "border-red-500/50";
                          bgClass = "bg-red-500/10";
                          icon = <XCircle className="h-5 w-5 text-red-400" />;
                        }
                      } else if (selected === idx) {
                        borderClass = "border-violet-500/50";
                        bgClass = "bg-violet-500/10";
                      }

                      return (
                        <button
                          key={idx}
                          onClick={() => handleSelect(idx)}
                          className={`flex w-full items-center gap-3 rounded-xl border ${borderClass} ${bgClass} p-4 text-left text-sm transition-all duration-200 ${!showResult ? "cursor-pointer" : "cursor-default"}`}
                          disabled={showResult}
                        >
                          <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-white/10 text-xs font-bold">
                            {String.fromCharCode(65 + idx)}
                          </span>
                          <span className="flex-1">{opt}</span>
                          {icon}
                        </button>
                      );
                    })}
                  </div>

                  {/* Explanation */}
                  <AnimatePresence>
                    {showResult && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        className="mt-4 overflow-hidden"
                      >
                        <div className="rounded-xl bg-slate-700/50 p-4 text-sm leading-relaxed text-slate-300">
                          <strong className="text-white">Explicación:</strong>{" "}
                          {q.explanation}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Actions */}
                  <div className="mt-6 flex justify-end gap-3">
                    {!showResult ? (
                      <Button
                        onClick={handleCheck}
                        disabled={selected === null}
                        className="gap-2 bg-gradient-to-r from-emerald-500 to-teal-600 text-white hover:from-emerald-600 hover:to-teal-700 disabled:opacity-50"
                      >
                        Verificar respuesta
                        <CheckCircle2 className="h-4 w-4" />
                      </Button>
                    ) : (
                      <Button
                        onClick={handleNext}
                        className="gap-2 bg-gradient-to-r from-violet-500 to-purple-600 text-white hover:from-violet-600 hover:to-purple-700"
                      >
                        {currentQ < quizQuestions.length - 1
                          ? "Siguiente pregunta"
                          : "Ver resultados"}
                        <ArrowRight className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ) : (
              /* Results */
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5 }}
              >
                <Card className="border-white/10 bg-white/5 backdrop-blur-xl">
                  <CardContent className="p-8 text-center">
                    <div
                      className={`mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full ${
                        percentage >= 80
                          ? "bg-gradient-to-br from-emerald-500 to-teal-600"
                          : percentage >= 60
                          ? "bg-gradient-to-br from-amber-500 to-orange-600"
                          : "bg-gradient-to-br from-rose-500 to-red-600"
                      } text-white shadow-lg`}
                    >
                      <Trophy className="h-10 w-10" />
                    </div>
                    <h3 className="text-2xl font-bold">
                      {percentage >= 80
                        ? "¡Excelente!"
                        : percentage >= 60
                        ? "¡Buen trabajo!"
                        : "¡Sigue practicando!"}
                    </h3>
                    <p className="mt-2 text-slate-400">
                      {percentage >= 80
                        ? "Tienes un dominio sólido de los conceptos de requerimientos tecnológicos."
                        : percentage >= 60
                        ? "Vas por buen camino. Repasa los temas donde fallaste."
                        : "Te recomendamos revisar nuevamente el material de la clase."}
                    </p>
                    <div className="mt-6 text-4xl font-bold text-emerald-400">
                      {score}/{quizQuestions.length}
                    </div>
                    <p className="text-sm text-slate-400">{percentage}% de aciertos</p>

                    {/* Answer summary */}
                    <div className="mt-6 grid grid-cols-5 gap-2">
                      {answers.map((a, i) => (
                        <TooltipProvider key={i}>
                          <Tooltip>
                            <TooltipTrigger>
                              <div
                                className={`flex h-10 w-full items-center justify-center rounded-lg text-sm font-bold ${
                                  a
                                    ? "bg-emerald-500/20 text-emerald-400"
                                    : "bg-red-500/20 text-red-400"
                                }`}
                              >
                                {a ? (
                                  <CheckCircle2 className="h-5 w-5" />
                                ) : (
                                  <XCircle className="h-5 w-5" />
                                )}
                              </div>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Pregunta {i + 1}</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      ))}
                    </div>

                    <Button
                      onClick={handleReset}
                      className="mt-8 gap-2 bg-white/10 text-white hover:bg-white/20"
                    >
                      <RotateCcw className="h-4 w-4" />
                      Reintentar quiz
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}

function SummarySection() {
  const keyPoints = [
    {
      icon: Target,
      title: "Define antes de comprar",
      text: "Siempre identifica las necesidades del negocio antes de adquirir tecnología. Un buen análisis inicial ahorra hasta un 40% en costos de infraestructura.",
    },
    {
      icon: HardDrive,
      title: "Los 6 componentes esenciales",
      text: "Hardware, software, red, seguridad, nube y almacenamiento son los pilares que debes evaluar en cada proyecto tecnológico.",
    },
    {
      icon: ClipboardList,
      title: "Sigue la metodología",
      text: "Los 6 pasos (identificar, inventariar, definir, evaluar, implementar, documentar) te garantizan un proceso completo y profesional.",
    },
    {
      icon: AlertTriangle,
      title: "Calcula el TCO real",
      text: "No mires solo el precio de compra. El costo total incluye operación, mantenimiento, capacitación y reemplazo durante la vida útil.",
    },
    {
      icon: Shield,
      title: "La seguridad es no negociable",
      text: "Integra seguridad desde el primer paso. Un incidente de seguridad puede costar más que toda la infraestructura del proyecto.",
    },
    {
      icon: BookOpen,
      title: "Documenta todo",
      text: "El documento de Especificación de Requerimientos Tecnológicos (ERT) es tu contrato de referencia. Debe estar firmado y ser accesible para todo el equipo.",
    },
  ];

  return (
    <section className="bg-white py-16 sm:py-20 lg:py-24">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={stagger}
        >
          <motion.div variants={fadeUp} custom={0} className="text-center">
            <Badge variant="secondary" className="mb-3">
              <Lightbulb className="mr-1.5 h-3.5 w-3.5" />
              Resumen y Puntos Clave
            </Badge>
            <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">
              Lo Que Debes Recordar
            </h2>
            <p className="mx-auto mt-3 max-w-2xl text-muted-foreground">
              Estos son los puntos más importantes que debes llevar contigo
              después de esta clase. Son la base de toda decisión tecnológica
              en gestión de proyectos.
            </p>
          </motion.div>

          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {keyPoints.map((point, i) => (
              <motion.div key={i} variants={fadeUp} custom={i + 1}>
                <Card className="group h-full border-border/50 transition-all duration-300 hover:border-emerald-200 hover:shadow-lg hover:shadow-emerald-500/5 dark:hover:border-emerald-800">
                  <CardContent className="p-6">
                    <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400">
                      <point.icon className="h-5 w-5" />
                    </div>
                    <h3 className="font-semibold">{point.title}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                      {point.text}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border/50 bg-slate-50 py-8 dark:bg-slate-900/30">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <GraduationCap className="h-4 w-4" />
            <span>Gestión de Proyectos — Nivel Básico</span>
          </div>
          <p className="text-center text-sm text-muted-foreground">
            Determinación de Requerimientos Tecnológicos e Infraestructura
          </p>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Clock className="h-4 w-4" />
            <span>Clase de 1 hora</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

/* ───────────── main page ───────────── */
export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <HeroSection />
      <ObjectivesSection />
      <ConceptsSection />
      <MethodologySection />
      <QuizSection />
      <SummarySection />
      <Footer />
    </div>
  );
}