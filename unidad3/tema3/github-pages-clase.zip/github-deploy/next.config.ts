import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "export",
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // Si el repo NO se despliega en la raíz del GitHub Pages,
  // descomenta y cambia '/nombre-del-repo/' por el nombre de tu repositorio:
  // basePath: '/nombre-del-repo/',
  // assetPrefix: '/nombre-del-repo/',
  images: {
    unoptimized: true,
  },
};

export default nextConfig;
