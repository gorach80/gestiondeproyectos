# Gestión de Proyectos — Requerimientos Tecnológicos e Infraestructura

Página web educativa interactiva para la clase de **Gestión de Proyectos** (nivel básico, 1 hora).

## Contenido

- **Hero** animado con datos de la clase
- **4 objetivos de aprendizaje**
- **6 componentes de infraestructura** (Hardware, Software, Red, Seguridad, Nube, Almacenamiento) con vista de tarjetas y acordeón detallado
- **Metodología en 6 pasos** con timeline y consejos prácticos
- **Quiz interactivo** de 5 preguntas con retroalimentación y resultados
- **Resumen** con puntos clave

## Tecnologías

- Next.js 16 (exportación estática)
- TypeScript
- Tailwind CSS 4
- shadcn/ui
- Framer Motion
- Lucide Icons

## Despliegue en GitHub Pages

### Opción 1: Automático con GitHub Actions (recomendado)

1. Crea un repositorio en GitHub
2. Sube el código a la rama `main`
3. Ve a **Settings → Pages**
4. En **Source**, selecciona **GitHub Actions**
5. Haz push y el workflow se ejecutará automáticamente

### Opción 2: Despliegue manual

```bash
# Instalar dependencias
bun install

# Generar sitio estático
bun run build

# La carpeta `out/` contiene el sitio listo
# Sube su contenido a la rama `gh-pages`
```

### Si tu repo NO está en la raíz de GitHub Pages

Si tu URL es `https://usuario.github.io/nombre-del-repo/`, edita `next.config.ts` y descomenta:

```ts
basePath: '/nombre-del-repo/',
assetPrefix: '/nombre-del-repo/',
```

Luego borra el archivo `public/CNAME` (solo se usa con dominios personalizados).

## Desarrollo local

```bash
bun install
bun run dev
```

Abre `http://localhost:3000` en tu navegador.